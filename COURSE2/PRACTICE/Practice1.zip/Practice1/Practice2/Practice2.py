import os
import shutil
import datetime

def create_or_replace_directory(dir_path):
    """
    Создает каталог по указанному пути.
    Если каталог существует — удаляет его и создает заново.
    """
    if os.path.exists(dir_path):
        print(f"!! Каталог {dir_path} уже существует. Каталог будет полностью удален...")
        shutil.rmtree(dir_path)
    
    print(f"Создание каталога {dir_path}...")
    os.mkdir(dir_path)
    print(f" ++ Каталог успешно создан")

new_file_path = "C:\\Users\\71602002\\OneDrive\\Desktop\\КОНСПЕКТЫ\\С++ украсть на флешку\\Practice1\\Practice1\\materials\\Task_1_Грек.txt"
file = open(new_file_path, 'r', encoding='utf-8')
all_lines = file.readlines()
count_lines = len(all_lines)
file.close()

catalog_name = 'ARCHIVE'
message = 'Введите N: '
message1 = 'Попробуйте ввести N еще раз: '
mkdir_mes = 'Создание каталога...\n'
new_mkdir_mes = f'Создан новый каталог {catalog_name}\n'

while True:
    try:
        N = int(input(message))

        if N <= 0:
            print('Ошибка: N должно быть положительным.')
            message = message1
        elif N > count_lines:
            print(f'Ошибка: N должно быть меньше {count_lines}')
            message = message1
        else:
            break
    except ValueError:
        print('Ошибка: количество файлов должно быть целым числом.')
        message = message1

homepath = os.path.expanduser("~")
archive_path = os.path.join(homepath, "ARCHIVE")

create_or_replace_directory(archive_path)

count = 1
while count <= N:
    filename = f"S_{count}.txt"
    full_path_new_file = os.path.join(archive_path, filename)
    new_file = open(full_path_new_file, 'w', encoding='utf-8')
    new_file.write(all_lines[count-1].rstrip('\n'))
    new_file.close()
    count += 1

max_size = 0
max_file = ""
count = 1

print('\nСОДЕРЖИМОЕ КАТАЛОГА ARCHIVE: ')
print(os.listdir(archive_path))

info_path = os.path.join(archive_path, "INFO")
info_file = open(info_path, 'w', encoding='utf-8')

while count <= N:
    file_path = os.path.join(archive_path, f"S_{count}.txt")
    
    size = os.path.getsize(file_path)
    
    ctime = os.path.getctime(file_path)
    ctime_str = datetime.datetime.fromtimestamp(ctime).strftime("%Y-%m-%d %H:%M:%S")
    
    now_str = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    info_file.write(f"Файл: S_{count}.txt | Размер: {size} байт | Дата создания: {ctime_str} | Системная дата: {now_str}\n")
    
    if size > max_size:
        max_size = size
        max_file = f"S_{count}.txt"
    
    count += 1

info_file.write(f"\nСамый большой файл: {max_file} размером в {max_size} байт")
info_file.close()

mp4_count = {}

root_folder = "C:\\"

for current_folder, subfolders, files in os.walk(root_folder):  # 
    for file_name in files:
        if file_name.lower().endswith('.mp4'):                  # 
            if file_name in mp4_count:
                mp4_count[file_name] += 1
            else:
                mp4_count[file_name] = 1

print("Файлы .mp4 с одинаковыми именами:")
found = False
for file_name, count in mp4_count.items():
    if count > 1:
        print(f"  {file_name} — встречается {count} раза")
        found = True

if not found:
    print("  Повторяющихся имён не найдено.")