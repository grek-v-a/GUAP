# Скопируйте без заголовка весь текст раздела II. 
# «Рекомендации по стилю программирования на Python» 
# в файл TASK_1_NAME.txt (вместо NAME впишите свою фамилию на латинице). 
# Напишите скрипт (код), выводящий отдельно число букв русского, 
# латинского алфавитов и цифр в TASK_1_NAME.txt, количество символов, 
# исключая пробельные в строках (с указанием номера строки), где встречается слово «Python»

# ---- БЛОК 0: подключение библиотек
from docx import Document

# ---- БЛОК 1: задавание переменных
original_file_path = "C:\\Users\\71602002\\Downloads\\_Методические указания.docx"
new_file_path = "C:\\Users\\71602002\\OneDrive\\Desktop\\КОНСПЕКТЫ\\С++ украсть на флешку\\Practice1\\Practice1\\materials\\Task_1_Грек.txt"
head = "Рекомендации по стилю программирования на Python"
end = "Задания по учебной практике"
doc = Document(original_file_path)
copy = False
selected_texts = []
flag_Phyton = "python"
ru_letters_count = 0
en_letters_count = 0
num_count = 0
ending = "ов"
end234 = ["4", "2", "3"]

# ---- БЛОК 2: запись в файл 
output_file = open(new_file_path, 'w', encoding='utf-8')

for paragraph in doc.paragraphs:
    if head in paragraph.text:
        copy = True
        continue                    # переход на следущий абзац
    if end in paragraph.text:
        copy = False
        break                       # выход из цикла
    if copy:
        output_file.write(paragraph.text)
        output_file.write('\n')

output_file.close()

# ---- БЛОК 3: поиск разных в файле
file = open(new_file_path, 'r', encoding='utf-8')

for line_number, line in enumerate(file, start=1):
    for l in line:
        if 'а' <= l <= 'я' or 'А' <= l <= 'Я' or l in 'ёЁ':
            ru_letters_count += 1
        elif 'a' <= l <= 'z' or 'A' <= l <= 'Z':
            en_letters_count += 1
        elif '0' <= l <= '9':
            num_count += 1

# ---- БЛОК 4: вывод символов для строк в которых встречается заданное слово
    if flag_Phyton in line.lower():
        no_space_gap = 0
        for sym in line:
            if sym != " " and sym != '\t':
                no_space_gap += 1
        
        end = str(no_space_gap)
        if end[-1] in end234:
            ending = "a"
        elif end[-1] == "1":
            ending = ""
        print(f"В строке {line_number} всего {no_space_gap} символ{ending}. Пробелы были удалены")

file.close()

print("-" * 20)
print(f"Русских букв: {ru_letters_count}")
print(f"Латинских букв: {en_letters_count}")
print(f"Цифр: {num_count}")